# Sunshine Prebuilt files for Windows
Used by [Sunshine](https://github.com/loki-47-6F-64/sunshine) to build ffmpeg libraries

Compiled using [media-autobuild_suite](https://github.com/m-ab-s/media-autobuild_suite) with the options present into the build folder (that must be included into the build folder in media-autobuild_suite)